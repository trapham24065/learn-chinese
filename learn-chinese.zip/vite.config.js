import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';

export default defineConfig({
    server: {
        host: 'learn-chinese.local',
        port: 5173,

        cors: true,

        hmr: {
            host: 'learn-chinese.local',
        },

        origin: 'http://learn-chinese.local:5173',
    },

    plugins: [
        laravel({
            input: [
                'resources/css/app.css',
                'resources/js/app.js',
            ],
            refresh: true,
        }),
    ],
});