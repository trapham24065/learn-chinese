<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="description" content="Chinese Deck - web học tiếng Trung với bài học ngắn, flashcard, quiz và tiến độ học tập.">

    <title>Learn Chinese</title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/favicon.png')); ?>">
    <?php echo app('Illuminate\Foundation\Vite')->fonts(); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="min-h-screen bg-[#f4ede3] text-slate-950 antialiased lg:pl-72">
    <aside class="fixed inset-y-0 left-0 z-40 hidden w-72 border-r border-white/70 bg-white/80 px-6 py-6 shadow-2xl shadow-slate-950/10 backdrop-blur lg:flex lg:flex-col">
        <a href="<?php echo e(route('home')); ?>" class="flex items-center gap-3 rounded-3xl border border-slate-200 bg-slate-950 px-4 py-4 text-white shadow-lg shadow-slate-950/15">
            <div class="grid h-12 w-12 place-items-center rounded-2xl bg-[#991b1b]">
                <span class="text-xl font-black">中</span>
            </div>
            <div>
                <p class="text-sm font-semibold uppercase tracking-[0.24em] text-amber-200/80">Learn Chinese</p>
                <p class="text-sm text-slate-300">Học tiếng Trung</p>
            </div>
        </a>

        <nav class="mt-6 space-y-2 text-sm font-medium">

            
            <a href="<?php echo e(route('dashboard')); ?>"
                class="group flex items-center justify-between rounded-2xl px-4 py-3 transition <?php echo e(request()->routeIs('dashboard') ? 'bg-[#991b1b] text-white shadow-lg shadow-red-950/15' : 'text-slate-700 hover:bg-slate-100 hover:text-[#991b1b]'); ?>">
                <span class="flex items-center gap-3">
                    <span class="grid h-8 w-8 place-items-center rounded-xl <?php echo e(request()->routeIs('dashboard') ? 'bg-white/10' : 'bg-slate-100'); ?>">
                        <i data-lucide="bar-chart-3" class="h-4 w-4"></i>
                    </span>
                    Tổng quan
                </span>
            </a>

            
            <a href="<?php echo e(route('home')); ?>"
                class="group flex items-center justify-between rounded-2xl px-4 py-3 transition <?php echo e(request()->routeIs('home') ? 'bg-[#991b1b] text-white shadow-lg shadow-red-950/15' : 'text-slate-700 hover:bg-slate-100 hover:text-[#991b1b]'); ?>">
                <span class="flex items-center gap-3">
                    <span class="grid h-8 w-8 place-items-center rounded-xl <?php echo e(request()->routeIs('home') ? 'bg-white/10' : 'bg-slate-100'); ?>">
                        <i data-lucide="house" class="h-4 w-4"></i>
                    </span>
                    Trang chủ
                </span>
            </a>

            
            <a href="<?php echo e(route('flashcards')); ?>"
                class="group flex items-center justify-between rounded-2xl px-4 py-3 transition <?php echo e(request()->routeIs('flashcards') ? 'bg-[#991b1b] text-white shadow-lg shadow-red-950/15' : 'text-slate-700 hover:bg-slate-100 hover:text-[#991b1b]'); ?>">
                <span class="flex items-center gap-3">
                    <span class="grid h-8 w-8 place-items-center rounded-xl <?php echo e(request()->routeIs('flashcards') ? 'bg-white/10' : 'bg-slate-100'); ?>">
                        <i data-lucide="layers" class="h-4 w-4"></i>
                    </span>
                    Thẻ ghi nhớ
                </span>
            </a>

            
            <a href="<?php echo e(route('quiz')); ?>"
                class="group flex items-center justify-between rounded-2xl px-4 py-3 transition <?php echo e(request()->routeIs('quiz') ? 'bg-[#991b1b] text-white shadow-lg shadow-red-950/15' : 'text-slate-700 hover:bg-slate-100 hover:text-[#991b1b]'); ?>">
                <span class="flex items-center gap-3">
                    <span class="grid h-8 w-8 place-items-center rounded-xl <?php echo e(request()->routeIs('quiz') ? 'bg-white/10' : 'bg-slate-100'); ?>">
                        <i data-lucide="file-text" class="h-4 w-4"></i>
                    </span>
                    Câu hỏi
                </span>
            </a>

            
            <a href="<?php echo e(route('hsk.overview')); ?>"
                class="group flex items-center justify-between rounded-2xl px-4 py-3 transition <?php echo e(request()->routeIs('hsk.*') ? 'bg-[#991b1b] text-white shadow-lg shadow-red-950/15' : 'text-slate-700 hover:bg-slate-100 hover:text-[#991b1b]'); ?>">
                <span class="flex items-center gap-3">
                    <span class="grid h-8 w-8 place-items-center rounded-xl <?php echo e(request()->routeIs('hsk.*') ? 'bg-white/10' : 'bg-slate-100'); ?>">
                        <i data-lucide="graduation-cap" class="h-4 w-4"></i>
                    </span>
                    HSK
                </span>
            </a>

        </nav>

        
        <div class="mt-4 rounded-[1.75rem] bg-[linear-gradient(135deg,_#111827_0%,_#1f2937_45%,_#991b1b_100%)] p-4 text-white shadow-xl shadow-slate-950/15">
            <div class="flex items-center justify-between">
                <p class="text-xs font-semibold uppercase tracking-[0.24em] text-amber-200/80">Streak học tập</p>
                <i data-lucide="flame" class="h-4 w-4 text-amber-400"></i>
            </div>
            <p class="mt-2 text-2xl font-black"><?php echo e(str_pad($sidebarStreak ?? 0, 2, '0', STR_PAD_LEFT)); ?></p>
            <p class="text-xs text-slate-300">ngày học liên tiếp</p>
            <div class="mt-3 h-1.5 rounded-full bg-white/10">
                <div class="h-1.5 rounded-full bg-gradient-to-r from-amber-300 to-red-400" style="width: <?php echo e(min(100, max(15, ($sidebarStreak ?? 0) * 15))); ?>%"></div>
            </div>
        </div>

        
        <div class="mt-auto pt-4 border-t border-slate-200/60">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($authUser): ?>
            <div class="flex items-center justify-between gap-2 rounded-2xl bg-slate-50 p-2.5">
                <a href="<?php echo e(route('profile.edit')); ?>" class="flex items-center gap-2.5 overflow-hidden hover:opacity-80 transition">
                    <div class="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-slate-900 text-xs font-bold text-white">
                        <?php echo e(strtoupper(substr($authUser->name ?? 'U', 0, 1))); ?>

                    </div>
                    <div class="truncate text-left">
                        <p class="truncate text-xs font-bold text-slate-900"><?php echo e($authUser->name); ?></p>
                        <p class="truncate text-[10px] text-slate-500"><?php echo e($authUser->email); ?></p>
                    </div>
                </a>
                <form method="POST" action="<?php echo e(route('logout')); ?>" class="shrink-0">
                    <?php echo csrf_field(); ?>
                    <button type="submit" title="Đăng xuất"
                        class="grid h-8 w-8 place-items-center rounded-xl bg-white text-slate-600 hover:bg-red-50 hover:text-red-600 border border-slate-200 transition">
                        <i data-lucide="log-out" class="h-4 w-4"></i>
                    </button>
                </form>
            </div>
            <?php else: ?>
            <div class="flex items-center gap-2">
                <a href="<?php echo e(route('login')); ?>" class="flex-1 text-center rounded-xl bg-slate-100 py-2 text-xs font-bold text-slate-800 hover:bg-slate-200 transition">Đăng nhập</a>
                <a href="<?php echo e(route('register')); ?>" class="flex-1 text-center rounded-xl bg-[#991b1b] py-2 text-xs font-bold text-white hover:bg-red-800 transition shadow-sm">Đăng ký</a>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </aside>

    <main class="min-h-screen">
        
        <div class="border-b border-white/70 bg-white/70 px-4 py-3 backdrop-blur lg:hidden">
            <div class="flex items-center justify-between gap-3">
                <a href="<?php echo e(route('home')); ?>" class="flex items-center gap-2.5">
                    <div class="grid h-8 w-8 place-items-center rounded-xl bg-[#991b1b] text-white">
                        <span class="text-sm font-black">中</span>
                    </div>
                    <div>
                        <p class="text-xs font-bold text-[#991b1b]">Chinese Deck</p>
                    </div>
                </a>
                <div class="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-slate-600">
                    <a href="<?php echo e(route('dashboard')); ?>" class="rounded-full px-2.5 py-1.5 <?php echo e(request()->routeIs('dashboard') ? 'bg-[#991b1b] text-white' : 'bg-slate-100'); ?>">Dashboard</a>
                    <a href="<?php echo e(route('flashcards')); ?>" class="rounded-full px-2.5 py-1.5 <?php echo e(request()->routeIs('flashcards') ? 'bg-[#991b1b] text-white' : 'bg-slate-100'); ?>">Flashcard</a>
                    <a href="<?php echo e(route('quiz')); ?>" class="rounded-full px-2.5 py-1.5 <?php echo e(request()->routeIs('quiz') ? 'bg-[#991b1b] text-white' : 'bg-slate-100'); ?>">Quiz</a>
                    <a href="<?php echo e(route('hsk.overview')); ?>" class="rounded-full px-2.5 py-1.5 <?php echo e(request()->routeIs('hsk.*') ? 'bg-[#991b1b] text-white' : 'bg-slate-100'); ?>">HSK</a>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($authUser): ?>
                    <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="rounded-full bg-red-50 text-red-700 px-2 py-1 text-[11px] font-bold">Thoát</button>
                    </form>
                    <?php else: ?>
                    <a href="<?php echo e(route('register')); ?>" class="rounded-full bg-[#991b1b] text-white px-2.5 py-1.5 text-[11px] font-bold">Đăng ký</a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>

        <div class="px-4 py-6 sm:px-6 lg:px-10 lg:py-8">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>
</body>

</html><?php /**PATH C:\wamp64\www\projects\Learn-Chinese\resources\views/layouts/app.blade.php ENDPATH**/ ?>